package com.infinite.Webapp.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.Webapp.Entity.DataClass;
import com.infinite.Webapp.Repository.DaoImplements;
@Service
public class Serviceimplements implements ServiceInterface{
	@Autowired
	DaoImplements di;
	@Transactional
	public List<DataClass> getAllData() {
		// TODO Auto-generated method stub
		return di.getAllData();
		
	}
	@Transactional
	public List<DataClass> getData(int id) {
		// TODO Auto-generated method stub
		return (List<DataClass>) di.getData(id);
	}
	@Transactional
	public void addData(DataClass dataclass) {
		// TODO Auto-generated method stub
		//return null;
		di.addData(dataclass);
	}
	@Transactional
	public void updateData(int id, DataClass dataclass) {
		// TODO Auto-generated method stub
		di.updateData(id, dataclass);
	}
	@Transactional
	public void deleteData(int id) {
		// TODO Auto-generated method stub
		di.deleteData(id);
	}
	@Transactional
	public DataClass login(String loginid, String password) {
		// TODO Auto-generated method stub
		return di.login(loginid, password);
	}

}
