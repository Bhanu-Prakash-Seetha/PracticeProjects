package com.infinite.Webapp.Repository;

import java.util.List;

import com.infinite.Webapp.Entity.DataClass;

public interface DaoClass {
	public List<DataClass> getAllData();
	public DataClass getData(int id);
	public void addData(DataClass dataclass);
	public void updateData(int id,DataClass dataclass);
	public void deleteData(int id);
	public DataClass login(String loginid,String password);
}
