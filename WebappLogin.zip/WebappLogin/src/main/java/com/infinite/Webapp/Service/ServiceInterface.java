package com.infinite.Webapp.Service;

import java.util.List;

import com.infinite.Webapp.Entity.DataClass;

public interface ServiceInterface {
	public List<DataClass> getAllData();
	public List<DataClass> getData(int id);
	public void addData(DataClass dataclass);
	public void updateData(int id,DataClass dataclass);
	public void deleteData(int id);
	public DataClass login(String loginid,String password);
}
