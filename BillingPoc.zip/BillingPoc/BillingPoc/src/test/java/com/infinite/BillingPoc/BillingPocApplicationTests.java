package com.infinite.BillingPoc;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingPocApplicationTests {

	//@Test
	void contextLoads() {
	}

}
