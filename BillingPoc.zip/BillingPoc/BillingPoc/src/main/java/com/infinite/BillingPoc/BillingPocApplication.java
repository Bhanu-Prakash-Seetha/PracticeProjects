package com.infinite.BillingPoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Component;

@SpringBootApplication
@EnableCaching(proxyTargetClass = true)
@Component
public class BillingPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingPocApplication.class, args);
	}

}
