package com.infinite.BillingPoc.Repository;

import java.util.List;

import com.infinite.BillingPoc.Entity.ProductDetails;

public interface BillingDao {
	public List<ProductDetails> getAllData();
	public void insert(ProductDetails pdetails);
	public void generatepdf(String filepath,List<ProductDetails> data);
}
