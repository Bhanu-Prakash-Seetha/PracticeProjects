package com.infinite.BillingPoc.Service;

import java.io.FileNotFoundException;
import java.util.List;

import com.infinite.BillingPoc.Entity.ProductDetails;
import com.itextpdf.text.DocumentException;

public interface BillingService {
	public List<ProductDetails> getAllData();
	public void insert(ProductDetails pdetails);
	public void generatepdf(String filepath,List<ProductDetails> data) throws DocumentException, FileNotFoundException;
}
