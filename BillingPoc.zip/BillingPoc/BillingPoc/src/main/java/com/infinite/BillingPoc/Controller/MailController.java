package com.infinite.BillingPoc.Controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.multipart.MultipartFile;

import com.infinite.BillingPoc.Entity.ProductDetails;
import com.infinite.BillingPoc.Service.BillingServiceimpls;
import com.itextpdf.text.DocumentException;


@Controller
public class MailController {
	@Autowired BillingServiceimpls si;
@RequestMapping(value="/",method=RequestMethod.GET,headers = "Accept=application/json")
public String gotohome(){
	return "redirect:/getAlldata";
}
@RequestMapping(value="/getAlldata",method=RequestMethod.GET,headers = "Accept=application/json")
public String getAlldata(Model model){
	//List<ProductDetails> pdetails = si.getAllData();
	//model.addAttribute("productdetails", pdetails);
	//model.addAttribute("ListOfProducts", si.getAllData());
	return "landing";
}
@RequestMapping(value="/getinsert",method=RequestMethod.POST,headers = "Accept=application/json")
public String getinsert(@ModelAttribute("pdetails") ProductDetails pdetails,Model model){
	si.insert(pdetails);
	List<ProductDetails> updateddetails = si.getAllData();
	model.addAttribute("productdetails",updateddetails );
	return "landing";
}
@RequestMapping(value="/getbill",method=RequestMethod.GET,headers="Accept=application/json")
public String gotodownload(){
	return "Generatedbill";
}

@RequestMapping(value="/download-pdf",method=RequestMethod.GET,headers="Accept=Application/json")
public void downloadpdf(HttpServletResponse response) throws DocumentException,IOException{
	List<ProductDetails> data = si.getAllData();
	String pdfFilePath = "generated-bill.pdf";
	si.generatepdf(pdfFilePath, data);
	response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment;filename=generated-bill.pdf");
	FileInputStream fileinputstream = new FileInputStream(pdfFilePath);
	IOUtils.copy(fileinputstream, response.getOutputStream());
	response.flushBuffer();
}
}


/*@GetMapping("/")
public String get(Model model) {
	List<ProductDetails> productdetails = si.getAllData();
	model.addAttribute("productdetails", productdetails);
	return "landing";
}

@PostMapping("/getinsert")
public String uploadMultipleFiles(@RequestParam("productdetails") ProductDetails productdetails) {
	for (MultipartFile productdetail: productdetails) {
		si.insert(productdetails);;
		
	}
	return "redirect:/";
}*/
