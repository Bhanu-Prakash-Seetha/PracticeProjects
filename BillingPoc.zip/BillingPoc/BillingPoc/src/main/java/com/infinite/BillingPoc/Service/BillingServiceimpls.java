package com.infinite.BillingPoc.Service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.BillingPoc.Entity.ProductDetails;
import com.infinite.BillingPoc.Repository.BillingDaoImpls;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
@Service
public class BillingServiceimpls implements BillingService{
	@Autowired BillingDaoImpls di;
	@Override
	@Transactional
	public List<ProductDetails> getAllData() {
		// TODO Auto-generated method stub
		return di.getAllData();
	}

	@Override
	@Transactional
	public void insert(ProductDetails pdetails) {
		// TODO Auto-generated method stub
		di.insert(pdetails);
	}

	@Override
	@Transactional
	public void generatepdf(String filepath, List<ProductDetails> data) throws DocumentException,FileNotFoundException {
		// TODO Auto-generated method stub
		Document document = new Document();
		PdfWriter.getInstance(document, new FileOutputStream(filepath));
		document.open();
		PdfPTable table = new PdfPTable(3);
		table.addCell("SerialNo");
		table.addCell("ProductName");
		table.addCell("Price");
		for(ProductDetails pd:data){
			table.addCell(String.valueOf(pd.getProductId()));
			table.addCell(String.valueOf(pd.getProductname()));
			table.addCell(String.valueOf(pd.getPrice()));
		}
		table.addCell("Total : ");
		document.add(table);
		document.close();
	}

}
