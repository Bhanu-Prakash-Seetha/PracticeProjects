package com.infinite.BillingPoc.Repository;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.BillingPoc.Entity.ProductDetails;
@Repository
public class BillingDaoImpls implements BillingDao{
	@Autowired SessionFactory sfactory;
	
	public void setSfactory(SessionFactory sfactory) {
		this.sfactory = sfactory;
	}
	
	public List<ProductDetails> getAllData() {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		List<ProductDetails> list = session.createQuery("from ProductDetails").list();
		return list;
	}
	
	public void insert(ProductDetails pdetails) {
		// TODO Auto-generated method stub
		Session session = this.sfactory.getCurrentSession();
		session.save(pdetails);
	}

	public void generatepdf(String filepath, List<ProductDetails> data) {
		// TODO Auto-generated method stub
		
	}

}
